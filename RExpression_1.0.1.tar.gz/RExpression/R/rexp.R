
rexp <- function(trt, trt.gn, ref.gn, graph.num){

  loadpack <- function(x) {
    if (require(x, character.only = T))
      return(require(x, character.only = T))
    else {install.packages(x)
      loadInstall(x)}
  }
  x <- 'readxl'
  loadpack(x)



  dt <-  read_excel(file.choose(), sheet = 1)
  #View(dt)
  dt <- dt[order(dt[, 1]),]
  dm <- dim(as.matrix(dt))


ref.gn <- as.matrix(dt[,as.numeric(ref.gn)])
trt.gn<- as.matrix(dt[,as.numeric(trt.gn)])
trt <- as.matrix(dt[,as.numeric(trt)])
  #####head(ref.gn)
  #####head(trt.gn)
  #####head(trt)

  df <- cbind(trt, ref.gn, trt.gn, (trt.gn - ref.gn))
  colnames(df) <- c("trt", "ref.gn", "trt.gn", "dlt1")
  ####View(df)


  d <-{}
  for(i in 1:nrow(df)) {
    if(df[i,1] ==0 | df[i,1] =="c" | df[i,1] == "C" | df[i,1] =="ctrl"
      | df[i,1] =="CTRL" | df[i,1] =="CONTROL"| df[i,1] =="control"
      | df[i,1] =="Control") {d[i]<-df[i, 4]}
  }


  avg.dlt <- matrix(mean(d), nrow(df), 1)
  df1 <- cbind(df, avg.dlt)
  df1 <- cbind(df1, (df1[, 4] - df1[, 5]))
  colnames(df1) <- c("trt", "ref.gn", "trt.gn", "dlt1", "avg.dlt",
                   "deltadelatCt")

  df2 <- as.data.frame(df1[, c(1, 4, 6)])
  df2 <- cbind(df2, (2^(df2$deltadelatCt*-1)))
  colnames(df2) <- c("trt", "dlt1", "dlt2", "rltv.exp")


  std <- aggregate(df2$rltv.exp, by=list(df2$trt), FUN=sd)
  colnames(std) <- c("trt", "sd")
  se <- std$sd/ (sqrt((nrow(df2)/length(unique(df2$trt)))))
  se <- cbind(std$trt, se)

  for(i in 1:nrow(df1)) {
    if(df1[i,1] ==0 | df1[i,1] =="c" | df1[i,1] == "C" | df1[i,1] =="ctrl"
      | df1[i,1] =="CTRL" | df1[i,1] =="CONTROL"| df1[i,1] =="control"
       | df1[i,1] =="Control") {df1[i, 6] = 0}
  }

  df3 <- as.data.frame(df1[, c(1, 4, 6)])
  df3 <- cbind(df3, (2^(df3$deltadelatCt*-1)))
  colnames(df3) <- c("trt", "dlt1", "dlt2", "rlt.exp")
  m <- aggregate(df3$rlt.exp, by=list(df3$trt), FUN=mean)
  colnames(m) <- c("trt", "Mean")


  mean_std <- cbind(m, se[,2])
  colnames(mean_std) <- c("treatment", "Mean", "Standard Error")
  pos_neg <- paste(round(mean_std$Mean,2), "+-",
        round(mean_std$`Standard Error`, 2))
  mean_std <- cbind(mean_std, pos_neg)
  View(mean_std)

  dr <- choose.dir()
  drr <- paste(dr,"\\mean_std.csv", sep = "")
  write.csv(mean_std, drr)


  df <- cbind.data.frame(df3$trt, df3$rlt.exp) ###raw data
  colnames(df) <- c("treatment", "rlative_expression")
  rept <- (nrow(df)/length(unique(df$treatment)))

  df$treatment <- as.factor(df$treatment)
  colnames(df) <- c("treatment", "rlative_expression")


  loadpack <- function(x) {
    if (require(x, character.only = T))
      return(require(x, character.only = T))
    else {install.packages(x)
      loadInstall(x)}
  }
  x <- 'dplyr'
  loadpack(x)
  x <- 'ggplot2'
  loadpack(x)

  df.summary <- df %>%
    group_by(treatment) %>%
    summarise(
      sd = sd(rlative_expression, na.rm = TRUE),
      se = sd/sqrt(rept),
      rlative_expression = mean(rlative_expression)
    )

  df.summary


  f <- ggplot(
    df.summary,
    aes(x = treatment, y = rlative_expression,
        ymin = rlative_expression-(se),
        ymax = rlative_expression+(se))
  )

  v1 <- f + geom_crossbar()
  v2 <- f + geom_errorbar()
  v3 <- f + geom_linerange()
  v4 <- f + geom_pointrange()
  #f + geom_errorbarh()

  v5 <- f + geom_errorbar(width = 0.2) +  geom_point(size = 1.5)



  #p <- ggplot(
  #  df.summary,
  #  aes(x = treatment, y = rlative_expression,
  #      xmin = treatment-(sd/rept),
  #      xmax = treatment+(sd/rept))
  #)
  #p + geom_point() + geom_errorbarh(height=0.2)


  # Combine with jitter points
  v6 <- ggplot(df, aes(treatment, rlative_expression)) +
    geom_jitter(position = position_jitter(0.2), color = "darkgray") +
    geom_pointrange(aes(ymin = rlative_expression-(sd/rept),
                        ymax = rlative_expression+(sd/rept)),
                    data = df.summary)

  # Combine with violin plots
  v7 <- ggplot(df, aes(treatment, rlative_expression)) +
    geom_violin(color = "darkgray", trim = FALSE) +
    geom_pointrange(aes(ymin = rlative_expression-(se),
                        ymax = rlative_expression+(se)),
                    data = df.summary)




  # (1) Line plot
  v8 <- ggplot(df.summary, aes(treatment, rlative_expression)) +
    geom_line(aes(group = 1)) +
    geom_errorbar(aes(ymin = rlative_expression-(se),
                      ymax = rlative_expression+(se)),
                  width = 0.2) +
    geom_point(size = 3)

  # (2) Bar plot
  v9 <- ggplot(df.summary, aes(treatment, rlative_expression)) +
    geom_col(fill = "lightgray", color = "black") +
    geom_errorbar(aes(ymin = rlative_expression-(se),
                      ymax = rlative_expression+(se)),
                  width = 0.2)


  # (1) Create a line plot of means +
  # individual jitter points + error bars
  v10 <- ggplot(df, aes(treatment, rlative_expression)) +
    geom_jitter( position = position_jitter(0.2), color = "darkgray") +
    geom_line(aes(group = 1), data = df.summary) +
    geom_errorbar(
      aes(ymin = rlative_expression-se, ymax = rlative_expression+se),
      data = df.summary, width = 0.2) +
    geom_point(data = df.summary, size = 2)



  # (2) Bar plots of means + individual jitter points + errors
  v11 <- ggplot(df, aes(treatment, rlative_expression)) +
    geom_col(data = df.summary, fill = NA, color = "black") +
    geom_jitter( position = position_jitter(0.2), color = "black") +
    geom_errorbar( aes(ymin = rlative_expression-se,
                       ymax = rlative_expression+se),
                   data = df.summary, width = 0.2)

  v <- as.numeric(graph.num)

  if (v == 1) {return(v1)}
  if (v == 2) {return(v2)}
  if (v == 3) {return(v3)}
  if (v == 4) {return(v4)}
  if (v == 5) {return(v5)}
  if (v == 6) {return(v6)}
  if (v == 7) {return(v7)}
  if (v == 8) {return(v8)}
  if (v == 9) {return(v9)}
  if (v == 10) {return(v10)}
  if (v == 11) {return(v11)}
  if (v == is.NULL) {return(v11)}


  }

# trt: number of the Column of treatment in the dataset
# trt.gn: number of the Column of Ct of favorit gene in the dataset
# ref.gn: the number of the Column of Ct of housekeeping gene in the dataset
# graph.num: can go from 1 to 11 indicating the graph type that user wants
